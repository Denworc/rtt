#ifndef RT_H
# define RT_H

#include <libft.h>
// # include "../lib/libft/libft.h"
# include "extra_function.h"
# include <stdlib.h>
# include <mlx.h>
# include <math.h>
# include <stdlib.h>
# include <time.h>

#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
// #include <stdio.h>

# define DEFAULT_WIDTH 1600
# define DEFAULT_HEIGHT 900
# define ERROR -1;
# define SUCCESS 1;

# define DEFAULT_CAM_X
# define DEFAULT_CAM_Y
# define DEFAULT_CAM_Z

// # define
//cam types
enum {DEFAULT, STEREOSCOPIC};

//obj

//need rename and and delete some types
enum { SPHERE, CONE, PLANE, CYLINDER, DISC,
	HYPERBOLOID_ONE, HYPERBOLOID_TWO, PARABOLOID, CHEWINGGUM, TORUS,
	QUADRIC, MOEBIUS, CUBE_TROUE, SELLE };

// CSG OPERATORS
enum { UNION, INTER, DIFF };

//LIGHT
enum { POINT, SPOT, DIRECTIONAL };


//texture
enum { NONE, MARBLE, WOOD, BMP, CHECKER };

//shadow
enum { HARD, SOFT };

//keymap

// enum {};


// typedef struct 		s_color
// {
// 	unsigned char 	r;
// 	unsigned char 	g;
// 	unsigned char 	b;
// }					t_color;

typedef struct 		s_refract
{
	int 			depth;
	int 			max;
	float 			normal1;
	float			normal2;
	int 			refraction_index;
}					t_refract;

typedef struct 		s_reflect
{
	int 			depth;
	int 			max;
}					t_reflect;

typedef struct 		s_ray
{
		
}					t_ray;

typedef struct 		s_file_info
{
	char 			*file;
	int 			fd;
}					t_file_info;

// ----------------------------------------------
typedef struct 		s_mouse
{
	
}					t_mouse;
// -----------------------------------------------
typedef struct 		s_scene
{
	int 			percent;
	int 			loading_image;
	int 			resync;
	int 			sample;
	float 			velocity;


	t_refract 		refract;
	t_reflect 		reflect;
	// int inc;

}					t_scene;



typedef struct 		s_image
{
	void 			*image;
	char			*str;
	int 			size_len;
	int 			bpp;
	int 			endian;
}					t_image;

// ----------------------------------------------
//need delete
typedef struct		s_line
{
	char			*line;
	struct s_line	*next;
	struct s_line	*prev;
}					t_line;

typedef struct		s_parse
{
	t_line			*scene;
	t_line			*cam;
	t_line			*obj;
	t_line			*lgt;
}					t_parse;

typedef struct		s_noise
{
	double			*noise;
	int				w_max;
	int				h_max;
	int				len;
	int				pas;
	int				octave;
	t_color			(*noise_func[3])(struct s_noise*, int, int);
}					t_noise;

typedef struct 		s_filter
{
	
}					t_filter;

typedef struct 		s_anti_aliasing
{
	int 			super_sample;
	float 			coef;
	float 			inc;	
}					t_anti_aliasing;

// -----------------------------------------------
typedef struct 		s_texture
{
	
}					t_texture;

typedef struct 		s_material
{
	// t_texture 		texture;

	float 			ambient_occlusion;
	float 			diffuse;

	float 			reflect;
	float 			refract;
	float 			glossy;

	float 			specular;
	float 			shine;

	float 			transparency;
	
	
}					t_material;

typedef struct 		s_obj
{

	t_vec3 			pos;
	t_vec3 			dir;

	t_vec3 			norm;


	t_material 		material;

	float			min;
	float 			max;

	unsigned int 	index;

	float 			dist;

	struct t_obj	*prev;
	struct t_obj	*next;	
}					t_obj;

typedef struct 		s_cam
{
	int 			pos_x;
	int 			pos_y;

	float 			aa_x;
	float			aa_y;

	// int type;
	
	char 			type;

	float 			dist;
	//mb need delete or custom
	float 			fov;

	t_vec3 			pos;
	t_vec3 			dir;
	t_vec3 			origin;

	t_ray 			ray;
	struct s_image 	image;
	t_filter 		filter;

	struct s_cam 	*next;
	struct s_cam 	*prev;
	struct s_cam 	*win;

	struct s_anti_aliasing aa;
	struct s_obj	*obj;
	int 			index;


	struct s_image	stereo;

}					t_cam;

typedef struct 		s_light
{
	t_vec3 			pos;
	t_vec3 			dir;
	// t_
	// t_ray 			ray;
	int 			type;

	float 			intensive;

	t_vec3 			color;
	// t_light 		*next;
}					t_light;

typedef struct 		s_mlx
{
	void			*mlx;
	void			*win;
	int 			width;
	int 			heigth;
}					t_mlx;

typedef struct 		s_env
{
	t_mlx			*mlx;
	t_file_info		file_arg;

	int 			width;
	int 			height;

	// t_frame			frame;

	t_mouse			mouse;
	t_scene			scene;
	t_cam			cam;

	t_obj			obj;
	t_light			light;

	// t_ray			ray;

	// t_reflect 		reflect;
	// t_refract 		refract;

	t_vec3			color;

}					t_env;


//init inter
void init_intersection(t_env *env);

//init normal
void init_normal(t_env *env);

//init scene
void init_default_scene_param(t_env *env);

//cam
void init_cam_param(t_env *env);

//main
void close(char *str);

//init.c
void init_file(t_env *env, char *file);
void init_default_param(t_env *env);

//parser
double    *add_gr(t_color **img, int y, int x, t_texture text);
int        obj_type(t_env *e, char *line);
t_texture        generate_texture(t_env *e, int type, int width, int height);
t_obj    *div_bbox(t_obj *original_box, t_env *e);
void    my_awesome_parser(t_env *e);
int        is_new_block(char *line);
t_cam    *create_cam(t_env *e, t_line *cam_line, t_cam *prev);
t_image    new_img(t_env *e);
t_light    *create_light(t_env *e, t_line *light_line);
void        arg_light(t_line *line, t_light *new);
t_obj        *new_object(t_env *e, t_line *object_line);
void    fill_buffer(t_env *e, const int fd, t_parse *buffer);
t_line    *init_list(t_env *e, char *line, t_line *prev);
void    fill_scene(t_env *e, t_parse *buffer);
void    fill_object_(t_env *e, t_line *line, t_obj *new);
int        fill_object(t_env *e, t_line *line, t_obj *new);
int        what_light(char *line);
t_color    check_gr(double *grad, t_obj *obj);
char        *get_tn(t_env *e, const char *line);
char    *get_line(t_env *e, const int fd, t_line *first);
void    del_buffer(t_parse *buffer);
short    get_tt(const char *line);
int        comment_line(const char *line);
int        next_(char *line, int i);
t_vec3    ft_pap(t_vec3 *vect, int pos, int max, char sign);
t_vec3    get_point(char *line, t_obj *parent);
t_vec3    *increase_size(t_env *e, t_vec3 *original, int *size);
int        check_objs(t_obj *obj);
double    ft_intens(t_color color);
void        csg_count(t_env *e, t_line **line);
t_vec3        range_vector(t_env *e, const char *line);
t_line    *load_buffer_elem(t_parse *buffer, int i);
double        range_value(const char *line, double min, double max);
short        is_true(const char *line);
t_vec3        convert_color(char *line);
int            check_csg(t_line *line);
void        add_stereo(t_env *e, t_cam *new);
void    add_scene(t_env *e, t_line *scene);
t_cam    *add_camera(t_env *e, t_line *cam_line);
t_obj    *add_bbox(t_obj *objs, t_env *e);
t_obj    *add_csg_obj(t_env *e, t_line *object_line);
void    add_cube_(t_obj *cube, double k);
void    add_cube(t_env *e, t_obj *cube);
void    add_nm(t_env *e, t_obj *obj);
t_obj    *add_object(t_env *e, t_line *object_line);
t_light    *add_light(t_env *e, t_line *light_line);
t_noise        add_noise(t_env *e, int w, int h);
void    add_texture(t_env *e, t_material *mat, char *line);
void    add_material(t_env *e, t_material *mat, t_line *line);
void    add_material_(t_env *e, t_material *mat, char *line);
t_obj    *add_p(t_env *e, int fd, t_obj *parent);
t_obj    *add_obj(char *file, t_env *e, t_obj *parent);
void    add_fr(t_obj *obj);
t_color    add_marble(t_noise *n, int x, int y);
void    add_func(t_noise *noise);
t_color    add_wood(t_noise *n, int x, int y);
void        add_fs(t_env *e, t_obj *csg, t_line *line);
void        add_op(t_env *e, t_obj *csg, char *line);
void        add_csg(t_env *e, t_obj *csg, t_line *line);
t_obj    *add_triangle(char *line, t_vec3 *vect, t_obj *parent, int max);
t_obj    *new_triangle(t_vec3 p1, t_vec3 p2, t_vec3 p3, t_obj *parent);
t_material    default_material(void);
void    default_object(t_obj *object);
void    default_light(t_light *light);
void    default_cam(t_env *e, t_cam *cam);


void parse_scene(t_env *env);
//normal

//intersection

//error


//generate texture noise perlin


#endif