#include "rt.h"

void init_intersection(t_env *env)
{
	
}