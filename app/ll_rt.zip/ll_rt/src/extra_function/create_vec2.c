#include "../../include/extra_function.h"

t_vec2 create_vec2(float x, float y)
{
	t_vec2i vector;

	vector.x = x;
	vector.y = y;
	return (vector);
}