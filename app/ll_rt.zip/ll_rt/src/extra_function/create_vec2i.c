#include "../../include/extra_function.h"

t_vec2i create_vec2i(int x, int y)
{
	t_vec2i vector;

	vector.x = x;
	vector.y = y;
	return (vector);
}