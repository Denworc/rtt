#include "../../include/extra_function.h"

t_vec3 color_to_vec3(t_color color)
{
	t_vec3 vector;

	vector.x = (float)color.x / 255;
	vector.y = (float)color.y / 255;
	vector.z = (float)color.z / 255;
	return (vector);
}