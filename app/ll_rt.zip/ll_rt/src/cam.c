#include "rt.h"

void init_cam_param(t_env *env)
{
	
}