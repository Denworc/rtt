
#include "rt.h"

t_vec3		quadric_n(t_vec3 *vector, t_obj *obj)
{
	t_vec3	result;

	result.x = 2 * obj->co.a * vector->x + obj->co.d * vector->y +
		obj->co.e * vector->z + obj->co.g;
	result.y = 2 * obj->co.b * vector->y + obj->co.d * vector->x +
		obj->co.f * vector->z + obj->co.h;
	result.z = 2 * obj->co.c * vector->z + obj->co.e * vector->x +
		obj->co.f * vector->y + obj->co.i;
	return (result);
}

t_vec3			selle_n(t_vec3 *hit, t_obj *abj)
{
	t_vec3	result;

	(void)abj;
	result.x = 2 * hit->x;
	result.z = -2 * hit->z;
	result.y = 1;
	return (result);
}

t_vec3		torus_n(t_vec3 *vector, t_obj *obj)
{
	t_vec3	result;

	result.x = 4 * vector->x * (vec3_dot(*vector, *vector) - (obj->gr + obj->pr));
	result.y = 4 * vector->y * (vec3_dot(*vector, *vector) - (obj->gr + obj->pr) + 2 * obj->gr);
	result.z = 4 * vector->z * (vec3_dot(*vector, *vector) - (obj->gr + obj->pr));
	return (result);
}