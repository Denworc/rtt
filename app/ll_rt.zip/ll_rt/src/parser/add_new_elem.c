
#include "rt.h"

void		add_fs(t_env *e, t_obj *csg, t_line *line)
{
	if (ft_strstr(line->line, "- object:"))
	{
		if (csg->left)
		{
			if (csg->right)
				error(e, E_OTYPE, line->line, 0);
			else
				csg->right = add_csg_obj(e, line->next);
		}
		else
			csg->left = add_csg_obj(e, line->next);
	}
}

void		add_op(t_env *e, t_obj *csg, char *line)
{
	if (ft_strstr(line, "- op:"))
	{
		if (ft_strstr(line, "UNION"))
			csg->op = UNION;
		else if (ft_strstr(line, "DIFF"))
			csg->op = DIFF;
		else if (ft_strstr(line, "INTER"))
			csg->op = INTER;
		else
			close("ERROR: add operation");
	}
}

void		add_csg(t_env *e, t_obj *csg, t_line *line)
{
	int			count_parenthesis;

	count_parenthesis = 1;
	while (line && !ft_strstr(line->line, "CSG"))
		line = line->prev;
	if (check_csg(line))
		close("ERROR: Wrong syntax for CSG object");
	line = line->next->next;
	while (line && count_parenthesis)
	{
		if (count_parenthesis == 1)
		{
			add_fs(e, csg, line);
			add_op(e, csg, line->line);
		}
		if (ft_strchr(line->line, '('))
			count_parenthesis++;
		else if (ft_strchr(line->line, ')'))
			count_parenthesis--;
		line = line->next;
	}
}

t_obj	*new_triangle(t_vec3 p1, t_vec3 p2, t_vec3 p3, t_obj *parent)
{
	t_obj	*result;

	if (!(result = (t_obj*)malloc(sizeof(*result))))
		return (NULL);
	default_object(result);
	result->type = TRIANGLE;
	result->pos = p1;
	result->pos2 = p2;
	result->pos3 = p3;
	result->mat = parent->mat;
	result->dir = vec3_norm(vec3_cross(vec3_sub(result->pos2, result->pos),
										vec3_sub(result->pos3, result->pos)));
	result->normal = result->dir;
	result->next = parent->comp;
	return (result);
}

t_obj	*add_triangle(char *line, t_vec3 *vect, t_obj *parent, int max)
{
	t_vec3	p1;
	t_vec3	p2;
	t_vec3	p3;
	int		i;

	i = 0;
	i = next_(line, i);
	p1 = ft_pap(vect, ft_atoi(line + i), max, line[i - 1]);
	i = next_(line, i);
	p2 = ft_pap(vect, ft_atoi(line + i), max, line[i - 1]);
	i = next_(line, i);
	p3 = ft_pap(vect, ft_atoi(line + i), max, line[i - 1]);
	if (!(parent->comp = new_triangle(p1, p2, p3, parent)))
		return (NULL);
	while (line[i])
	{
		i = next_(line, i);
		if (line[i])
			if (!(parent->comp = new_triangle(p1, parent->comp->pos3,
										vect[ft_atoi(line + i)], parent)))
				return (NULL);
	}
	return (parent->comp);
}