
#include "rt.h"

t_mat	default_material(void)
{
	t_mat	mat;

	mat.color = vec3(1, 1, 1);
	mat.reflect = 0;
	mat.refract = 0;
	mat.ambient = 0.1;
	mat.diffuse = 0.1;
	mat.specular = 1.0;
	mat.transparency = 0;
	mat.absorbtion = 0;
	mat.shininess = 256;
	mat.glossiness = 0;
	mat.texture.type = NONE;
	mat.texture.defined = 0;
	mat.texture.transparency_mapping = 0;
	mat.normal_perturbation = 0;
	mat.texture.filtering = 0;
	mat.texture.normal_map = 0;
	mat.texture.rotation = 0;
	mat.texture.normal_strength = 1;
	mat.receive_shadow = 1;
	mat.fresnel.defined = 0;
	mat.texture.scale = 1;
	return (mat);
}

void	default_object(t_obj *object)
{
	object->type = SPHERE;
	object->pos = vec3(0, 0, 0);
	object->pos2 = vec3(0, 1, 0);
	object->pos3 = vec3(1, 0, 0);
	object->dir = vec3(0, 1, 0);
	object->cut = vec3(0, 0, 0);
	object->rot = vec3(0, 0, 0);
	object->comp = NULL;
	object->next = NULL;
	object->left = NULL;
	object->right = NULL;
	object->m = 1;
	object->pr = 1;
	object->gr = 2;
	object->scale = 1;
	object->min = -INFINITY;
	object->max = INFINITY;
	object->mat = default_material();
}

void	default_light(t_lgt *light)
{
	light->type = POINT;
	light->scale = 0.12;
	light->pos = vec3(0, 0, 0);
	light->dir = vec3(0, 0, 1);
	light->color = vec3(1, 1, 1);
	light->intensity = 1;
	light->attenuation = 0.05;
	light->cutoff = 75;
	light->cutoff_outer = 2;
	light->shadow_intensity = 0.7;
	light->shadow = HARD;
}

void	default_cam(t_env *e, t_cam *cam)
{
	if (cam != NULL)
	{
		cam->type = DEFAULT;
		cam->pos = vec3_zero();
		cam->dir = vec3(0, 0, 1);
		cam->img = new_img(e);
		cam->filter.invert = 0;
		cam->filter.gray_scale = 0;
		cam->filter.gamma = 1.0;
		cam->index = 0;
		cam->fov = 60;
		cam->selection = NULL;
		cam->twin = NULL;
		cam->aa.supersampling = 1;
	}
}

