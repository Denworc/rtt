
#include "rt.h"

t_vec3	*increase_size(t_env *e, t_vec3 *original, int *size)
{
	t_vec3	*new;
	int		increment;

	increment = 1000;
	*size = *size + increment;
	if (!(new = (t_vec3*)malloc(sizeof(*new) * (*size))))
		close("ERROR");
	ft_memcpy(new, original, sizeof(*original) * (*size - increment));
	free(original);
	return (new);
}

int		check_objs(t_obj *obj)
{
	int		i;

	i = 0;
	if (obj == NULL)
		return (0);
	while (obj)
	{
		if (obj->type == BBOX)
			i = i + check_objs(obj->comp);
		else
			i++;
		obj = obj->next;
	}
	return (i);
}

double	ft_intens(t_rgb color)
{
	double		m;
	t_vec3		tmp;

	tmp = rgb_to_vec3(color);
	m = (tmp.x + tmp.y + tmp.z) / 3.0;
	return (m);
}

void		csg_count(t_env *e, t_line **line)
{
	int		i;

	if (ft_strchr((*line)->line, '('))
	{
		i = 1;
		while (i)
		{
			*line = (*line)->next;
			if (!*line)
				close("ERROR");
			if (ft_strchr((*line)->line, ')'))
				i--;
			if (ft_strchr((*line)->line, '('))
				i++;
		}
	}
}

t_line	*load_buffer_elem(t_parse *buffer, int i)
{
	if (i == 0)
		return (buffer->cam);
	else if (i == 1)
		return (buffer->lgt);
	else if (i == 2)
		return (buffer->obj);
	else
		return (buffer->scene);
}

