
#include "rt.h"

void		add_stereo(t_env *e, t_cam *new)
{
	t_cam	*win;

	!(win = (t_cam*)malloc(sizeof(t_cam))) ? close("ERROR") : 0;
	win->type = STEREOSCOPIC;
	win->dir = new->dir;
	win->fov = new->fov;
	// win->image = img_init(e);
	// win->filter.invert = 0;
	// win->filter.gray_scale = 0;
	// win->filter.gamma = 1.0;
	win->aa.super_sample = new->aa.super_sample;
	win->next = NULL;
	win->prev = NULL;
	win->win = new;
	new->win = win;
}

t_cam	*add_camera(t_env *e, t_line *cam_line)
{
	t_line	*line;
	t_cam	*tmp;
	t_cam	*camera;
	t_cam	*current;

	line = cam_line;
	if (!(current = (t_cam*)malloc(sizeof(t_cam))))
		close("ERROR");
	current->next = NULL;
	camera = current;
	while (line != NULL)
	{
		if (ft_strstr(line->line, "- camera:"))
		{
			current->next = create_cam(e, line->next, current);
			current = current->next;
			camera->next->prev = current;
			current->next = camera->next;
		}
		line = line->next;
	}
	tmp = camera;
	camera = camera->next;
	ft_memdel((void**)&tmp);
	return (camera);
}

void	add_scene(t_env *e, t_line *scene)
{
	t_line *line;

	line = scene;
	while (line != NULL)
	{
		if (ft_strstr(line->line, "recursion_reflect:"))
			e->scene.reflect.max = range_value(line->line, 0, 16);
		else if (ft_strstr(line->line, "recursion_refract:"))
			e->scene.refract.max = range_value(line->line, 0, 16);
		else if (ft_strstr(line->line, "velocity:"))
			e->scene.velocity = range_value(line->line, 0, 100);
		else if (ft_strstr(line->line, "load_resync:"))
			e->scene.resync = is_true(line->line);
		else if (ft_strstr(line->line, "load_percent:"))
			e->scene.percent = is_true(line->line);
		else if (ft_strstr(line->line, "progressive_loading:"))
			e->scene.loading_image = is_true(line->line);
		else if (ft_strstr(line->line, "sampling:"))
			e->scene.sample = range_value(line->line, 0, 4096);
		line = line->next;
	}
}

t_obj	*add_bbox(t_obj *objs, t_env *e)
{
	t_obj	*i;
	t_obj	*nb;

	if (!(nb = (t_obj*)malloc(sizeof(*nb))))
		close("ERROR");
	default_object(nb);
	nb->type = BBOX;
	i = objs;
	nb->pos = i->pos;
	nb->pos2 = i->pos2;
	while (i != NULL)
	{
		if (i->type == TRIANGLE)
		{
			nb->pos.x = min4(nb->pos.x, i->pos.x, i->pos2.x, i->pos3.x);
			nb->pos.y = min4(nb->pos.y, i->pos.y, i->pos2.y, i->pos3.y);
			nb->pos.z = min4(nb->pos.z, i->pos.z, i->pos2.z, i->pos3.z);
			nb->pos2.x = max4(nb->pos2.x, i->pos.x, i->pos2.x, i->pos3.x);
			nb->pos2.y = max4(nb->pos2.y, i->pos.y, i->pos2.y, i->pos3.y);
			nb->pos2.z = max4(nb->pos2.z, i->pos.z, i->pos2.z, i->pos3.z);
		}
		i = i->next;
	}
	nb->comp = objs;
	return (nb);
}

t_obj	*add_csg_obj(t_env *e, t_line *object_line)
{
	t_obj		*new;
	t_line		*line;

	line = object_line;
	!(new = (t_obj*)malloc(sizeof(t_obj))) ? close("ERROR") : 0;
	default_object(new);
	while (line != NULL && !ft_strstr(line->line, "- object:"))
	{
		fill_object(e, line, new);
		line = line->next;
	}
	if (new->mat.texture.normal_map && new->mat.texture.defined)
		add_nm(e, new);
	new->pr *= new->pr;
	new->gr *= new->gr;
	new->scale2 = new->scale * new->scale;
	new->k = tan(new->scale) * tan(new->scale);
	if (new->type == TRIANGLE || new->type == PARALLELOGRAM)
		new->dir = vec3_norm(vec3_cross(new->pos2, new->pos3));
	if (new->type == CUBE)
		add_cube(e, new);
	(new->type != BBOX && new->type != CUBE) ? new->comp = NULL : 0;
	if (new->type == CSG)
		add_csg(e, new, line);
	return (new);
}