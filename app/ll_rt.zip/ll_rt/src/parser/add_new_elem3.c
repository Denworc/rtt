
#include "rt.h"

t_noise		add_noise(t_env *e, int w, int h)
{
	int		i;
	int		poctave;
	t_noise	noise;

	i = -1;
	noise.octave = 7;
	noise.pas = 100;
	poctave = pow(2, noise.octave - 1);
	noise.w_max = (int)ceil(w * poctave / noise.pas);
	noise.h_max = (int)ceil(h * poctave / noise.pas);
	noise.len = noise.w_max * noise.h_max;
	if (!(noise.noise = (double*)malloc(sizeof(double) * noise.len)))
		// close("ERROR: ")
	while (++i < noise.len)
		noise.noise[i] = ((double)rand()) / RAND_MAX;
	return (noise);
}

void	add_texture(t_env *e, t_mat *mat, char *line)
{
	mat->texture.name = get_tn(e, line);
	mat->texture.type = get_tt(mat->texture.name);
	if (mat->texture.type == NONE || mat->texture.type == CHECKER)
		return ;
	else if (mat->texture.type == BMP)
		bmp_importer(e, ft_strstr(line, ":") + 2, &mat->texture);
	else
		mat->texture = generate_texture(e, mat->texture.type, T_RESW, T_RESH);
}

void	add_material_(t_env *e, t_mat *mat, char *line)
{
	if (ft_strstr(line, "refract:"))
		mat->refract = range_value(line, 0, 10);
	else if (ft_strstr(line, "texture_transparency:"))
		mat->texture.transparency_mapping = is_true(line);
	else if (ft_strstr(line, "absorbtion:"))
		mat->absorbtion = range_value(line, 0, 1);
	else if (ft_strstr(line, "texture:"))
		add_texture(e, mat, line);
	else if (ft_strstr(line, "texture_filtering:"))
		mat->texture.filtering = is_true(line);
	else if (ft_strstr(line, "receive_shadow:"))
		mat->receive_shadow = is_true(line);
	else if (ft_strstr(line, "texture_normal:"))
		mat->texture.normal_map = is_true(line);
	else if (ft_strstr(line, "texture_normal_strength:"))
		mat->texture.normal_strength = range_value(line, 0, 20);
	else if (ft_strstr(line, "texture_size:"))
		mat->texture.scale = 1.0 / range_value(line, 0, 100);
	else if (ft_strstr(line, "texture_rotation:"))
		mat->texture.rotation = range_value(line, 0, 360);
	else if (ft_strstr(line, "normal_perturbation:"))
		mat->normal_perturbation = is_true(line);
	else if (ft_strstr(line, "transparency:"))
		mat->transparency = range_value(line, 0, 1);
}

void	add_material(t_env *e, t_mat *mat, t_line *line)
{
	while (line != NULL && !ft_strstr(line->line, "- object:"))
	{
		if (ft_strstr(line->line, "color:"))
			mat->color = convert_color(line->line);
		else if (ft_strstr(line->line, "ambient:"))
			mat->ambient = range_value(line->line, 0, 1);
		else if (ft_strstr(line->line, "diffuse:"))
			mat->diffuse = range_value(line->line, 0, 10);
		else if (ft_strstr(line->line, "specular:"))
			mat->specular = range_value(line->line, 0, 50);
		else if (ft_strstr(line->line, "shininess:"))
			mat->shininess = range_value(line->line, 0, 16384);
		else if (ft_strstr(line->line, "glossiness:"))
			mat->glossiness = range_value(line->line, 0, 2);
		else if (ft_strstr(line->line, "reflect:"))
			mat->reflect = range_value(line->line, 0, 1);
		else if (ft_strstr(line->line, "fresnel:"))
			mat->fresnel.defined = is_true(line->line);
		else
			add_material_(e, mat, line->line);
		line = line->next;
	}
}

void	add_fr(t_obj *obj)
{
	obj->mat.fresnel.reflect = pow((obj->mat.refract - 1.0) /
		(obj->mat.refract + 1.0), 2);
	obj->mat.fresnel.refract = 1.0 - obj->mat.fresnel.reflect;
}