
#include "rt.h"

t_obj	*add_p(t_env *e, int fd, t_obj *parent)
{
	int		size;
	t_vec3	*points;
	int		i;
	char	*line;

	size = 1000;
	if (!(points = (t_vec3*)malloc(sizeof(*points) * 1000)))
		close("ERROR: add point (malloc error");
	i = 1;
	while (get_next_line(fd, &line) > 0)
	{
		i >= size - 1 ? points = increase_size(e, points, &size) : 0;
		if (line[0] == 'v' && line[1] == ' ')
		{
			points[i] = get_point(line, parent);
			i++;
		}
		else if (line[0] == 'f' && line[1] == ' ')
			if (!(parent->comp = add_triangle(line, points, parent, i - 1)))
				close("ERROR: add point (malloc error");
		ft_strdel(&line);
	}
	ft_strdel(&line);
	free(points);
	return (parent);
}

t_obj	*add_obj(char *file, t_env *e, t_obj *parent)
{
	int		fd;
	t_obj	*new_box_size;
	char	*trim;

	parent->type = BBOX;
	trim = ft_strtrim(file);
	(fd = open(trim, O_RDWR)) == -1 ? close("ERROR: add object. open error") : 0;
	free(trim);
	add_p(e, fd, parent);
	if (parent->comp)
	{
		new_box_size = add_bbox(parent->comp, e);
		parent->pos = new_box_size->pos;
		parent->pos2 = new_box_size->pos2;
		free(new_box_size);
		parent = div_bbox(parent, e);
		e->count.obj = e->count.obj + check_objs(parent) - 1;
		// close(fd);
	}
	return (parent);
}

t_rgb	add_marble(t_noise *n, int x, int y)
{
	double	f;
	t_rgb	color;

	f = 1 - sqrt(fabs(sin(2 * PI * noise(n, x, y))));
	color.x = (1.0 * (1 - f) + 0.7 * f) * 255;
	color.y = (1.0 * (1 - f) + 0.7 * f) * 255;
	color.z = (1.0 * (1 - f) + 0.7 * f) * 255;
	return (color);
}

t_rgb	add_wood(t_noise *n, int x, int y)
{
	double	f;
	double	value;
	t_rgb	color;
	t_vec3	c1;
	t_vec3	c2;

	c1 = vec3(1.0, 0.99, 0.98);
	c2 = vec3(0.2, 0.12, 0.02);
	value = fmod(noise(n, x, y), 0.2);
	if (value > 0.2 / 2)
		value = 0.2 - value;
	f = (1 - cos(PI * value / (0.2 / 2))) / 2;
	color.x = (c1.x * (1 - f) + c2.x * f) * 255;
	color.y = (c1.x * (1 - f) + c2.y * f) * 255;
	color.z = (c1.z * (1 - f) + c2.z * f) * 255;
	return (color);
}

void	add_func(t_noise *noise)
{
	noise->noise_func[0] = NULL;
	noise->noise_func[1] = add_marble;
	noise->noise_func[2] = add_wood;
}