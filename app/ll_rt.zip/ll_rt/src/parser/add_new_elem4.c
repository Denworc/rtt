
#include "rt.h"

void	add_cube_(t_obj *cube, double k)
{
	cube->comp[3].pos = vec3_add(cube->comp[0].pos, (t_vec3) {0, k, 0});
	cube->comp[3].pos2 = (t_vec3) {k, 0, 0};
	cube->comp[3].pos3 = (t_vec3) {0, 0, k};
	cube->comp[3].dir = vec3(0, 1, 0);
	cube->comp[4].pos = cube->comp[0].pos;
	cube->comp[4].pos2 = (t_vec3) {k, 0, 0};
	cube->comp[4].pos3 = (t_vec3) {0, 0, k};
	cube->comp[4].dir = vec3(0, -1, 0);
	cube->comp[5].pos = vec3_add(cube->comp[0].pos, (t_vec3) {k, 0, k});
	cube->comp[5].pos2 = (t_vec3) {-k, 0, 0};
	cube->comp[5].pos3 = (t_vec3) {0, k, 0};
	cube->comp[5].dir = vec3(0, 0, 1);
}

void	add_cube(t_env *e, t_obj *cube)
{
	double	k;

	!(cube->comp = malloc(6 * sizeof(t_obj))) ? error(e, E_MALLOC, NULL, 0) : 0;
	k = cube->scale;
	cube->comp[0].pos = vec3_sub(cube->pos, vec3(k / 2, k / 2, k / 2));
	cube->comp[0].pos2 = (t_vec3) {k, 0, 0};
	cube->comp[0].pos3 = (t_vec3) {0, k, 0};
	cube->comp[0].dir = vec3(0, 0, -1);
	cube->comp[1].pos = vec3_add(cube->comp[0].pos, (t_vec3) {k, 0, 0});
	cube->comp[1].pos2 = (t_vec3) {0, 0, k};
	cube->comp[1].pos3 = (t_vec3) {0, k, 0};
	cube->comp[1].dir = vec3(1, 0, 0);
	cube->comp[2].pos = vec3_add(cube->comp[0].pos, (t_vec3) {0, 0, k});
	cube->comp[2].pos2 = (t_vec3) {0, 0, -k};
	cube->comp[2].pos3 = (t_vec3) {0, k, 0};
	cube->comp[2].dir = vec3(-1, 0, 0);
	add_cube_(cube, k);
}

void	add_nm(t_env *e, t_obj *obj)
{
	int		x;
	int		y;
	double	*grad;

	y = -1;
	grad = NULL;
	obj->mat.texture.bump =
	(t_rgb**)malloc(sizeof(t_rgb*) * obj->mat.texture.h);
	obj->mat.texture.bump == NULL ? close("ERROR") : 0;
	while (++y < obj->mat.texture.h)
	{
		x = -1;
		obj->mat.texture.bump[y] =
		(t_rgb*)malloc(sizeof(t_rgb) * obj->mat.texture.w);
		obj->mat.texture.bump[y] == NULL ? close("ERROR") : 0;
		while (++x < obj->mat.texture.w)
		{
			grad = add_gr(obj->mat.texture.img, y, x, obj->mat.texture);
			grad == NULL ? close("ERROR") : 0;
			obj->mat.texture.bump[y][x] = check_gr(grad, obj);
			ft_memdel((void**)&grad);
		}
	}
}

t_obj	*add_object(t_env *e, t_line *object_line)
{
	t_line	*line;
	t_obj	*tmp;
	t_obj	*object;
	t_obj	*current;

	line = object_line;
	if (!(current = (t_obj*)malloc(sizeof(t_obj))))
		close("ERROR");
	current->next = NULL;
	object = current;
	while (line != NULL)
	{
		csg_count(e, &line);
		if (ft_strstr(line->line, "- object:"))
		{
			current->next = new_object(e, line->next);
			current = current->next;
		}
		line = line->next;
	}
	tmp = object;
	object = object->next;
	ft_memdel((void**)&tmp);
	return (object);
}

t_lgt	*add_light(t_env *e, t_line *light_line)
{
	t_line	*line;
	t_lgt	*tmp;
	t_lgt	*light;
	t_lgt	*current;

	line = light_line;
	if (!(current = (t_lgt*)malloc(sizeof(t_lgt))))
		close("ERROR");                                                       /////////////////ERROR must be
	current->next = NULL;
	light = current;
	while (line != NULL)
	{
		if (ft_strstr(line->line, "- light:"))
		{
			current->next = create_light(e, line->next);
			current = current->next;
		}
		line = line->next;
	}
	tmp = light;
	light = light->next;
	ft_memdel((void**)&tmp);
	return (light);
}