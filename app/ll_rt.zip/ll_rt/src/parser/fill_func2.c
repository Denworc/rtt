
#include "rt.h"

t_obj		*new_object(t_env *e, t_line *object_line)
{
	t_obj		*new;
	t_line		*line;

	line = object_line;
	!(new = (t_obj*)malloc(sizeof(t_obj))) ? error(e, E_OINIT, NULL, 1) : 0;
	default_object(new);
	while (line != NULL && !ft_strstr(line->line, "- object:") &&
		!ft_strchr(line->line, '(') && fill_object(e, line, new))
		line = line->next;
	e->count.obj++;
	new->id = e->count.obj;
	if (new->mat.texture.normal_map && new->mat.texture.defined)
		add_nm(e, new);
	new->scale2 = new->scale * new->scale;
	new->pr *= new->pr;
	new->gr *= new->gr;
	new->k = tan(new->scale) * tan(new->scale);
	if (new->type == TRIANGLE || new->type == PARALLELOGRAM)
		new->dir = vec3_norm(vec3_cross(new->pos2, new->pos3));
	new->type == CUBE ? add_cube(e, new) : 0;
	new->type == CSG ? add_csg(e, new, line) : 0;
	(new->type != BBOX && new->type != CUBE) ? new->comp = NULL : 0;
	new->mat.fresnel.defined ? add_fr(new) : 0;
	return (new);
}

void		arg_light(t_line *line, t_lgt *new)
{
	if (ft_strstr(line->line, "scale:"))
		new->scale = range_value(line->line, 0, 10);
	else if (ft_strstr(line->line, "shadow_intensity:"))
		new->shadow_intensity = range_value(line->line, 0, 1);
	else if (ft_strstr(line->line, "shadow:"))
		new->shadow = ft_strstr(line->line, "SOFT") ? SOFT : HARD;
	else if (ft_strstr(line->line, "intensity:"))
		new->intensity = range_value(line->line, 0, 10);
	else if (ft_strstr(line->line, "attenuation:"))
		new->attenuation = range_value(line->line, 0.0000001, 10);
	else if (ft_strstr(line->line, "cutoff:"))
		new->cutoff = range_value(line->line, 0, 360);
	else if (ft_strstr(line->line, "cutoffouter:"))
		new->cutoff_outer = range_value(line->line, 0, 180);
}

t_lgt	*create_light(t_env *e, t_line *light_line)
{
	t_lgt		*new;
	t_line		*line;

	line = light_line;
	!(new = (t_lgt*)malloc(sizeof(t_lgt))) ? error(e, E_LINIT, NULL, 1) : 0;        /////////////////ERROR must be
	default_light(new);
	while (line != NULL && !ft_strstr(line->line, "- light:"))
	{
		if (ft_strstr(line->line, "type:"))
			new->type = what_light(line->line);
		else if (ft_strstr(line->line, "pos:"))
			new->pos = range_vector(e, line->line);
		else if (ft_strstr(line->line, "dir:"))
			new->dir = range_vector(e, line->line);
		else if (ft_strstr(line->line, "color:"))
			new->color = convert_color(line->line);
		arg_light(line, new);
		line = line->next;
	}
	e->count.lgt++;
	new->next = NULL;
	new->cutoff_outer = cos((new->cutoff + new->cutoff_outer) * 0.5 * DEG2RAD);
	new->cutoff = cos(new->cutoff * 0.5 * DEG2RAD);
	return (new);
}

t_img	new_img(t_env *e)
{
	t_img	img;

	if (!(img.adr = mlx_new_image(e->mlx, e->win.w, e->win.h)))
		close("ERROR");
	if (!(img.img = mlx_get_data_addr(img.adr, &img.bpp, &img.sl,
		&img.endian)))
		close("ERROR");
	img.opp = img.bpp / 8;
	img.h = e->win.h;
	img.w = e->win.w;
	return (img);
}

t_cam	*create_cam(t_env *e, t_line *cam_line, t_cam *prev)
{
	t_cam		*new;
	t_line		*line;

	line = cam_line;
	!(new = (t_cam*)malloc(sizeof(t_cam))) ? close("ERROR") : 0;        /////////////////ERROR must be
	default_cam(e, new);
	while (line != NULL && !ft_strstr(line->line, "- camera:"))
	{
		if (ft_strstr(line->line, "type:") && ft_strstr(line->line, "STEREO"))
			new->type = STEREOSCOPIC;
		else if (ft_strstr(line->line, "pos:"))
			new->pos = range_vector(e, line->line);
		else if (ft_strstr(line->line, "dir:"))
			new->dir = range_vector(e, line->line);
		else if (ft_strstr(line->line, "fov:"))
			new->fov = range_value(line->line, 1, 180);
		else if (ft_strstr(line->line, "supersampling:"))
			new->aa.supersampling = range_value(line->line, 1, 16);
		line = line->next;
	}
	e->count.cam++;
	new->type == STEREOSCOPIC ? add_stereo(e, new) : 0;
	new->prev = prev;
	new->next = NULL;
	return (new);
}