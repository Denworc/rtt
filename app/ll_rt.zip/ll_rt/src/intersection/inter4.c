#include "rt.h"

double		cube_troue(t_ray *r, t_obj *obj)
{
	double		a[5];
	double		root[4];
	t_vec3		x;
	int			ret;

	obj->in = INFINITY;
	obj->out = INFINITY;
	x = r->position;
	a[4] = ft_pow(r->dir.x, 4) + ft_pow(r->dir.y, 4) + ft_pow(r->dir.z, 4);
	a[3] = (4 * (ft_pow(r->dir.x, 3) * x.x + ft_pow(r->dir.y, 3) * x.y +
		ft_pow(r->dir.z, 3) * x.z)) / a[4];
	a[2] = (6 * (ft_pow(r->dir.x, 2) * ft_pow(x.x, 2) + ft_pow(r->dir.y, 2) *
		ft_pow(x.y, 2) + ft_pow(r->dir.z, 2) * ft_pow(x.z, 2)) -
		5 * vec3_dot(r->dir, r->dir)) / a[4];
	a[1] = (4 * (ft_pow(x.x, 3) * r->dir.x + ft_pow(x.y, 3) * r->dir.y +
		ft_pow(x.z, 3) * r->dir.z) - 10 * vec3_dot(r->dir, x)) / a[4];
	a[0] = (ft_pow(x.x, 4) + ft_pow(x.y, 4) + ft_pow(x.z, 4) -
		5 * vec3_dot(x, x) + obj->scale) / a[4];
	ret = solve_quartic(a, root);
	if (ret >= 2)
	{
		obj->in = root[0];
		obj->out = root[1];
	}
	return (choose_root4(root, ret));
}

double			chewing_gum(t_ray *ray, t_obj *obj)
{
	int			ret;
	t_vec3		x;
	double		a[5];
	double		roots[4];

	obj->in = INFINITY;
	obj->out = INFINITY;
	x = ray->position;
	a[4] = ft_pow(ray->dir.x, 4) + ft_pow(ray->dir.y, 4) + ft_pow(ray->dir.z, 4);
	a[3] = (4 * (ft_pow(ray->dir.x, 3) * x.x + ft_pow(ray->dir.y, 3) * x.y +
		ft_pow(ray->dir.z, 3) * x.z)) / a[4];
	a[2] = (6 * (ft_pow(ray->dir.x, 2) * ft_pow(x.x, 2) + ft_pow(ray->dir.y, 2)
		* ft_pow(x.y, 2) + ft_pow(ray->dir.z, 2) * ft_pow(x.z, 2))) / a[4];
	a[1] = (4 * (ray->dir.x * ft_pow(x.x, 3) + ray->dir.y * ft_pow(x.y, 3) +
		ray->dir.z * ft_pow(x.z, 3))) / a[4];
	a[0] = (ft_pow(x.x, 4) + ft_pow(x.y, 4) + ft_pow(x.z, 4) -
		ft_pow(obj->scale, 4)) / a[4];
	ret = solve_quartic(a, roots);
	if (ret >= 2)
	{
		obj->in = roots[0];
		obj->out = roots[1];
	}
	return (choose_root4(roots, ret));
}

double	cylinder(t_ray *ray, t_obj *obj)
{
	double		a[3];
	double		roots[2];
	double		ro;
	double		lo;
	int			ret;

	obj->in = INFINITY;
	obj->out = INFINITY;
	vec3_normalize(&obj->dir);
	ro = vec3_dot(ray->dir, obj->dir);
	lo = vec3_dot(ray->pos, obj->dir);
	a[2] = 1.0 - ro * ro;
	a[1] = 2 * (vec3_dot(ray->dir, ray->pos) - ro * lo);
	a[0] = vec3_dot(ray->pos, ray->pos) - lo * lo - obj->scale * obj->scale;
	if (!(ret = solve_quadratic(a, roots)))
		return (INFINITY);
	obj->in = roots[0];
	obj->out = roots[1];
	if (obj->in < 0 && ((obj->in = obj->out) || 1))
		if (obj->in < 0)
			return (INFINITY);
	return (compute_m(ray, obj, is_vec3_nul(obj->cut) ? obj->dir : obj->cut));
}

double	plane(t_ray *ray, t_obj *obj)
{
	t_calc	calc;

	obj->in = INFINITY;
	obj->out = INFINITY;
	calc.a = vec3_dot(obj->dir, ray->dir);
	calc.b = vec3_dot(obj->dir, ray->pos);
	if (calc.a == 0)
		return (INFINITY);
	calc.eq = -calc.b / calc.a;
	if (calc.eq > 0 && (obj->in = calc.eq))
		return (calc.eq);
	else
		return (INFINITY);
}