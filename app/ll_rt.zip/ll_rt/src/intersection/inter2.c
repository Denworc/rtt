#include "rt.h"

t_calc		init_quadric_calc(t_ray *ray, t_obj *obj)
{
	t_calc	c;

	c.len = ray->position;
	c.a = obj->co.a * ray->dir.x * ray->dir.x + obj->co.b * ray->dir.y *
		ray->dir.y + obj->co.c * ray->dir.z * ray->dir.z + obj->co.d *
		ray->dir.x * ray->dir.y + obj->co.e * ray->dir.x * ray->dir.z +
		obj->co.f * ray->dir.y * ray->dir.z;
	c.b = 2 * (ray->dir.x * c.len.x * obj->co.a + ray->dir.y * c.len.y *
		obj->co.b + ray->dir.z * c.len.z * obj->co.c) + obj->co.d * (ray->dir.x
		* c.len.y + ray->dir.y * c.len.x) + obj->co.e * (ray->dir.x * c.len.z +
		ray->dir.z * c.len.x) + obj->co.f * (ray->dir.y * c.len.z + ray->dir.z
		* c.len.y) + obj->co.g * ray->dir.x + obj->co.h * ray->dir.y + obj->co.i
		* ray->dir.z;
	c.c = obj->co.a * c.len.x * c.len.x + obj->co.b * c.len.y * c.len.y +
		obj->co.c * c.len.z * c.len.z + obj->co.d * c.len.x * c.len.y +
		obj->co.e * c.len.x * c.len.z + obj->co.f * c.len.y * c.len.z
		+ obj->co.g * c.len.x + obj->co.h * c.len.y + obj->co.i * c.len.y
		+ obj->co.j;
	return (c);
}

double		quadric(t_ray *ray, t_obj *obj)
{
	t_calc	c;

	c = init_quadric_calc(ray, obj);
	if (c.a == 0)
	{
		if (c.b)
			obj->t = -c.c / c.b;
		else
			obj->t = c.c ? -1 : 0;
		return (obj->t);
	}
	c.disc = c.b * c.b - 4 * c.a * c.c;
	if (c.disc < EPSILON)
		return (INFINITY);
	c.disc = sqrt(c.disc);
	c.eq = -c.b - c.disc;
	if (c.eq < -EPSILON)
		c.eq = -c.b + c.disc;
	obj->t = c.eq;
	return (c.eq);
}

double	paraboloid(t_ray *ray, t_obj *o)
{
	double	a[5];
	double	xv;
	double	dv;
	t_vec3	x;
	int		ret;

	o->in = INFINITY;
	o->out = INFINITY;
	x = ray->position;
	xv = vec3_dot(x, o->dir);
	dv = vec3_dot(ray->dir, o->dir);
	a[2] = vec3_dot(ray->dir, ray->dir) - dv * dv;
	a[1] = 2 * (vec3_dot(ray->dir, x) - dv * (xv + 2 * o->scale));
	a[0] = vec3_dot(x, x) - xv * (xv + 4 * o->scale);
	if (!(ret = solve_quadratic(a, &a[3])))
		return (INFINITY);
	o->in = a[3];
	o->out = a[4];
	if (o->in < 0 && ((o->in = o->out) || 1))
		if (o->in < 0)
			return (INFINITY);
	return (compute_m(ray, o, is_vec3_nul(o->cut) ? o->dir : o->cut));
}

double	hyperboloid1(t_ray *ray, t_obj *o)
{
	double	a[3];
	double	roots[2];
	int		ret;
	t_vec3	x;

	o->in = INFINITY;
	o->out = INFINITY;
	x = ray->position;
	a[2] = ray->dir.x * ray->dir.x - ray->dir.y * ray->dir.y +
		ray->dir.z * ray->dir.z;
	a[1] = 2 * (x.x * ray->dir.x - x.y * ray->dir.y +
		x.z * ray->dir.z);
	a[0] = x.x * x.x - x.y * x.y +
		x.z * x.z - o->scale2;
	if (!(ret = solve_quadratic(a, roots)))
		return (INFINITY);
	o->in = roots[0];
	o->out = roots[1];
	if (o->in < EPSILON)
	{
		o->in = o->out;
		if (o->in < EPSILON)
			return (INFINITY);
	}
	return (compute_m(ray, o, is_vec3_nul(o->cut) ? o->dir : o->cut));
}

double	hyperboloid2(t_ray *ray, t_obj *o)
{
	double	a[3];
	double	roots[2];
	int		ret;
	t_vec3	x;

	o->in = INFINITY;
	o->out = INFINITY;
	x = ray->position;
	a[2] = ray->dir.x * ray->dir.x - ray->dir.y * ray->dir.y +
		ray->dir.z * ray->dir.z;
	a[1] = 2 * (x.x * ray->dir.x - x.y * ray->dir.y +
		x.z * ray->dir.z);
	a[0] = x.x * x.x - x.y * x.y +
		x.z * x.z + o->scale2;
	if (!(ret = solve_quadratic(a, roots)))
		return (INFINITY);
	o->in = roots[0];
	o->out = roots[1];
	if (o->in < EPSILON)
	{
		o->in = o->out;
		if (o->in < EPSILON)
			return (INFINITY);
	}
	return (compute_m(ray, o, is_vec3_nul(o->cut) ? o->dir : o->cut));
}