#include "rt.h"

void		fonction_relativement_assez_nulle(double *r, double *zarr)
{
	r[0] = zarr[0];
	r[1] = zarr[1];
	r[2] = zarr[2];
	r[3] = zarr[3];
}

static void	compute_coeffs(t_ray *ray, t_obj *obj, double *a)
{
	t_vec3	x;
	double	dd;
	double	e;
	double	f;
	double	four_aa;

	x = ray->position;
	dd = vec3_dot(ray->dir, ray->dir);
	e = vec3_dot(x, x) - obj->gr - obj->pr;
	f = vec3_dot(x, ray->dir);
	four_aa = 4 * obj->gr;
	a[0] = (e * e - four_aa * (obj->pr - x.y * x.y)) / dd * dd;
	a[1] = (4 * f * e + 2 * four_aa * x.y * ray->dir.y) / dd * dd;
	a[2] = (2 * dd * e + 4 * f * f + four_aa * ray->dir.y * ray->dir.y) /
		dd * dd;
	a[3] = (4 * dd * f) / dd * dd;
}

double		torus(t_ray *ray, t_obj *obj)
{
	double	a[4];
	double	roots[4];
	int		num_real_roots;

	compute_coeffs(ray, obj, a);
	num_real_roots = solve_quartic(a, roots);
	if (num_real_roots == 0)
		return (INFINITY);
	if (num_real_roots == 2)
	{
		if (roots[0] < 0)
			return (roots[1] < 0 ? INFINITY : roots[1]);
		else
			return (roots[0]);
	}
	num_real_roots = 0;
	while (num_real_roots < 4)
	{
		if (roots[num_real_roots] > 0)
			return (roots[num_real_roots]);
		num_real_roots++;
	}
	return (INFINITY);
}

static double	cut_selle(t_ray *ray, t_obj *o, double tmp)
{
	t_vec3	hit;

	hit = vec3_add(ray->position, vec3_fmul(ray->dir, tmp));
	if (hit.x > o->max || hit.x < o->min || hit.y > o->max || hit.y < o->min ||
		hit.z > o->max || hit.z < o->min)
	{
		hit = vec3_add(ray->position, vec3_fmul(ray->dir, o->out));
		if (hit.x > o->max || hit.x < o->min || hit.y > o->max ||
			hit.y < o->min || hit.z > o->max || hit.z < o->min)
			return (INFINITY);
		tmp = o->out;
	}
	return (tmp);
}

double			selle(t_ray *ray, t_obj *o)
{
	double	a[5];
	int		ret;

	o->in = INFINITY;
	o->out = INFINITY;
	a[2] = ray->dir.x * ray->dir.x - ray->dir.z * ray->dir.z;
	a[1] = 2 * (ray->dir.x * ray->position.x - ray->dir.z * ray->position.z) +
		ray->dir.y;
	a[0] = ray->position.x * ray->position.x - ray->position.z *
		ray->position.z + ray->position.y;
	if (!(ret = solve_quadratic(a, &a[3])))
		return (INFINITY);
	o->in = a[3];
	o->out = a[4];
	if (o->in < 0)
	{
		o->in = o->out;
		if (o->in < 0)
			return (INFINITY);
	}
	return (cut_selle(ray, o, o->in));
}