#include "rt.h"

double	compute_m(t_ray *r, t_obj *o, t_vec3 cut)
{
	double		m;

	o->m = 0;
	m = vec3_dot(r->dir, cut) * o->in + vec3_dot(r->pos, cut);
	if (m > o->max || m < o->min)
	{
		o->in = o->out;
		o->out = INFINITY;
		m = vec3_dot(r->dir, cut) * o->in + vec3_dot(r->pos, cut);
		if (m < o->max && m > o->min && ((o->m = m) || 1))
			return (o->in);
		else if ((o->in = INFINITY))
			return (INFINITY);
	}
	o->m = m;
	return (o->in);
}

double	cone(t_ray *ray, t_obj *obj)
{
	double		lo;
	double		ro;
	double		a[3];
	double		roots[2];
	int			ret;

	obj->in = INFINITY;
	obj->out = INFINITY;
	lo = vec3_dot(ray->pos, obj->dir);
	ro = vec3_dot(ray->dir, obj->dir);
	a[2] = 1.0 - (1 + obj->k) * ro * ro;
	a[1] = 2 * (vec3_dot(ray->dir, ray->pos) - (1 + obj->k) * ro * lo);
	a[0] = vec3_dot(ray->pos, ray->pos) - (1 + obj->k) * lo * lo;
	if (!(ret = solve_quadratic(a, roots)))
		return (INFINITY);
	obj->in = roots[0];
	obj->out = roots[1];
	if (obj->in < 0 && ((obj->in = obj->out) || 1))
		if (obj->in < 0)
			return (INFINITY);
	return (compute_m(ray, obj, is_vec3_nul(obj->cut) ? obj->dir : obj->cut));
}

double	sphere(t_ray *ray, t_obj *obj)
{
	t_calc	calc;

	obj->in = INFINITY;
	obj->out = INFINITY;
	calc.len = ray->pos;
	calc.b = vec3_dot(calc.len, ray->dir);
	calc.c = vec3_dot(calc.len, calc.len) - obj->scale2;
	calc.disc = calc.b * calc.b - calc.c;
	if (calc.disc < EPSILON)
		return (INFINITY);
	calc.disc = sqrt(calc.disc);
	calc.eq = -calc.b - calc.disc;
	obj->in = calc.eq;
	obj->out = calc.eq + 2 * calc.disc;
	if (calc.eq < -EPSILON)
		calc.eq = obj->out;
	return (calc.eq);
}