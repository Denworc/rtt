// #include "../inlcude/rt.h"
#include "rt.h"

int valid_file_format(char *file_name)
{
	char *format;

	format = ft_strrchr(file_name, '.');
	if (format == NULL)
		return (0);
	if (ft_strcmp(format, ".yml") != 0)
		return (0);
	return (1);
}

//need add close fd function
void init_file(t_env *env, char *file)
{
	if (valid_file_format(file))
		env->file_arg.file = file;
	else
		close("Not falid file format. Need use yml");
	if ((env->file_arg.fd = open(file, O_RDWR)) == -1)
		close("File can not open");
	// close_fd(&env);
}

void init_mlx_param(t_env *env)
{
	t_mlx *mlx;

	mlx = (t_mlx *)malloc(sizeof(t_mlx));
	(mlx == NULL) ? close("Cant init mlx") : 0;
	mlx->mlx = mlx_init();
	mlx->win = mlx_new_window(mlx, env->width, env->height, "RT");
	env->mlx = mlx;
}

//need add 2 function/ mlx work
void init_default_param(t_env *env)
{
	env->width = DEFAULT_WIDTH;
	env->height = DEFAULT_HEIGHT;
	// init_mlx_param(env);
	
	// init_mouse_paran(&env);
	// init_cam_param(&env);
}