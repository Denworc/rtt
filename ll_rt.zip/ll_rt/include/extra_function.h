#ifndef EXTRA_FINCTION_H
# define EXTRA_FINCTION_H

#include <math.h>

# define PI 3.1415926
# define DEG2RAD PI / 180
# define RAD2DEG 180 / PI
# define ABS(x) (x < 0 ? -x : x)

enum {X, Y, Z};

typedef struct 		s_vec3
{
	float			x;
	float 			y;
	float 			z;
}					t_vec3;

typedef struct 		s_vec2
{
	float 			x;
	float 			y;
}					t_vec2;

typedef struct 		s_vec3i
{
	int 			x;
	int				y;
	int 			z;
}					t_vec3i;

typedef struct 		s_vec2i
{
	int 			x;
	int 			y;
}					t_vec2i;

typedef struct 		s_color
{
	unsigned char	x;
	unsigned char	y;
	unsigned char	z;
}					t_color;

//vec3 function


t_vec3 				create_vec3(float x, float y, float z);
t_vec3 				vec3_add(t_vec3 vector1, t_vec3 vector2);
t_vec3 				vec3_sub(t_vec3 vector1, t_vec3 vector2);
t_vec3 				vec3_mult(t_vec3 vector1, t_vec3 vector2);
t_vec3 				vec3_fmult(t_vec3 vector1, float arg);
float 				vec3_dot(t_vec3 vector1, t_vec3 vector2);
t_vec3 				vec3_norm(t_vec3 vector);
t_vec3i 			vec3_convert(t_vec3 vec3);
void				vec3_normalize(t_vec3 *vector);
t_vec3 				vec3_scale(t_vec3 vector, float scale);
t_vec3 				vec3_cross(t_vec3 vector1, t_vec3 vector2);
void 				vec3_rot(t_vec3 *vector, int xyz, float alfa);
int 				vec3_rotate(t_vec3 *vector, t_vec3 vec3_rotate);
int 				vec3_inverse_rotate(t_vec3 *vector, t_vec3 vec3_rotate);
//vec3i
t_vec3i 			create_vec3i(int x, int y, int z);

//vec2 function
t_vec2 				create_vec2(float x, float y);


//vec2i
t_vec2i 			create_vec2i(int x, int y);

//extra function
t_color 			vec3_to_color(t_vec3 vector);
t_vec3 				color_to_vec3(t_color color);
t_vec3 				vec3_reflect(t_vec3 vector, t_vec3 norm);
int 				vec3_is_zero(t_vec3 vector);

#endif