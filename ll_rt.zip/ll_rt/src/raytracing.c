#include "rt.h"

int start_raytracing(t_env *env)
{
	return (1);
}