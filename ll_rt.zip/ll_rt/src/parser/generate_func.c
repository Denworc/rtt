
#include "rt.h"

t_obj	*div_bbox(t_obj *original_box, t_env *e)
{
	int		nb_objs;
	int		i;
	t_obj	*objs;
	t_obj	*new_box;

	objs = original_box->comp;
	nb_objs = check_objs(objs);
	i = 0;
	if (nb_objs <= 100)
		return (original_box);
	while (i < ((nb_objs / 2) - 1) && objs)
	{
		objs = objs->next;
		i++;
	}
	if (objs)
	{
		new_box = add_bbox(objs->next, e);
		objs->next = NULL;
		original_box->comp = add_bbox(original_box->comp, e);
		original_box->comp->next = new_box;
		original_box->comp->next = div_bbox(original_box->comp->next, e);
		original_box->comp = div_bbox(original_box->comp, e);
	}
	return (original_box);
}

t_texture		generate_texture(t_env *e, int type, int width, int height)
{
	int			x;
	int			y;
	t_noise		noise;
	t_texture	text;

	text.w = width;
	text.h = height;
	text.defined = 1;
	text.normal_map = 0;
	noise = add_noise(e, width, height);
	add_func(&noise);
	if (!(text.img = (t_rgb**)malloc(sizeof(t_rgb*) * height)))
		close("ERROR");
	y = -1;
	while (++y < height)
	{
		x = -1;
		if (!(text.img[y] = (t_rgb*)malloc(sizeof(t_rgb) * width)))
			close("ERROR");
		while (++x < width)
			if (type < 3 && type > 0)
				text.img[y][x] = noise.noise_func[type](&noise, x, y);
	}
	ft_memdel((void**)&noise.noise);
	return (text);
}

int		obj_type(t_env *e, char *line)
{
	int		i;
	char	*type;

	i = -1;
	if (!(type = ft_strtrim(ft_strchr(line, ':') + 1)))
		close("ERROR");
	while (g_object_type[++i].reference != NULL)
	{
		if (ft_strcmp(type, g_object_type[i].reference) == 0)
		{
			ft_strdel(&type);
			return (g_object_type[i].index);
		}
	}
	close("ERROR");
	ft_strdel(&type);
	return (SPHERE);
}

double	*add_gr(t_rgb **img, int y, int x, t_texture text)
{
	double	actual;
	double	*grad;

	grad = NULL;
	if ((grad = (double*)malloc(sizeof(double) * 4)) == NULL)
		return (NULL);
	actual = ft_intens(img[y][x]);
	grad[0] = (y - 1 > 0 ? ft_intens(img[y - 1][x]) : actual);
	grad[1] = (x - 1 > 0 ? ft_intens(img[y][x - 1]) : actual);
	grad[2] = (x + 1 < text.w ? ft_intens(img[y][x + 1]) : actual);
	grad[3] = (y + 1 < text.h ? ft_intens(img[y + 1][x]) : actual);
	return (grad);
}