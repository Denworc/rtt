
#include "rt.h"

int		is_new_block(char *line)
{
	return (ft_strncmp(line, "cameras:", 8) == 0 ||
			ft_strncmp(line, "lights:", 7) == 0 ||
			ft_strncmp(line, "objects:", 8) == 0 ||
			ft_strncmp(line, "scenes:", 6) == 0);
}


void	my_awesome_parser(t_env *e)
{
	t_parse		buffer;

	if ((e->arg.fd = open(e->arg.file, O_RDWR)) == -1)
		close("ERROR");                //// ERROR must be
	buffer.scene = init_list(e, "scene", NULL);
	buffer.cam = init_list(e, "cameras", NULL);	
	buffer.lgt = init_list(e, "lights", NULL);
	buffer.obj = init_list(e, "objects", NULL);
	fill_buffer(e, e->arg.fd, &buffer);
	if (close(e->arg.fd) == -1)
		close("ERROR");
	fill_scene(e, &buffer);
}

void parse_scene(t_env *env)
{
	my_awesome_parser(env);
}