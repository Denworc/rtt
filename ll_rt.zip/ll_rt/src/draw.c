#include "rt.h"

void draw(t_env *env)
{
	if (env->scene.loading_image)
		start_progressive_raytracing();
	else
		!start_raytracing(&env) ? close("Raytracing ERROR") : 0;
	
	

}