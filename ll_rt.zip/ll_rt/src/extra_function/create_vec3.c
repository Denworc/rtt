#include "../../include/extra_function.h"

t_vec3 create_vec3(float x, float y, float z)
{
	t_vec3 vector;

	vector.x = x;
	vector.y = y;
	vector.z = z;
	return (vector);
}