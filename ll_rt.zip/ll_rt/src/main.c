#include "rt.h"

void close(char *str)
{
	ft_putendl(str);
	exit(0);
}

//need add man
static void display_argc(void)
{
	// ft_putendl("");
	// ft_putendl();
	close("Close RT");
}

int main(int argc, char *argv[])
{
	t_env env;

	(argc < 2) ? display_argc() : 0;
	(argc == 2) ? init_file(&env, argv[1]) : display_argc();
	init_default_param(&env);
	init_intersection(&env);
	init_normal(&env);
	parse_scene(&env);
	// draw(&env);
	// init_hook(&env);
	// clean(&env, SUCCESS);
	close("Close RT SUCCESS1");
	return 0;
}