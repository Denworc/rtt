#include "rt.h"

void init_default_scene_param(t_env *env)
{
	
}