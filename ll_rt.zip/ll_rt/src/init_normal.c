#include "rt.h"

void init_normal(t_env *env)
{

}